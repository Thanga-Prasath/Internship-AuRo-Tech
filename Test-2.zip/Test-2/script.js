document.getElementById('addTaskButton').addEventListener('click', addTask);

function addTask() {
    const taskInput = document.getElementById('taskInput');
    const taskText = taskInput.value.trim();

    if (taskText !== '') {
        const taskList = document.getElementById('taskList');

        const taskItem = document.createElement('li');
        taskItem.className = 'task-item';

        const taskSpan = document.createElement('span');
        taskSpan.textContent = taskText;
        taskItem.appendChild(taskSpan);

        const taskButtons = document.createElement('div');
        taskButtons.className = 'task-buttons';

        const completeButton = document.createElement('button');
        completeButton.className = 'complete-btn';
        completeButton.textContent = '✔';
        completeButton.addEventListener('click', () => {
            taskItem.classList.toggle('completed');
        });

        const deleteButton = document.createElement('button');
        deleteButton.className = 'delete-btn';
        deleteButton.textContent = '✖';
        deleteButton.addEventListener('click', () => {
            taskList.removeChild(taskItem);
        });

        taskButtons.appendChild(completeButton);
        taskButtons.appendChild(deleteButton);
        taskItem.appendChild(taskButtons);

        taskList.appendChild(taskItem);
        taskInput.value = '';
    }
}

document.getElementById('taskInput').addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        addTask();
    }
});